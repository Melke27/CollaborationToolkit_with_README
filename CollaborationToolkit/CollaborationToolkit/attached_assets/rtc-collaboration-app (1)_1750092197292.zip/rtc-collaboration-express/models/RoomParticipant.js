module.exports = (sequelize, DataTypes) => {
  const RoomParticipant = sequelize.define('RoomParticipant', {
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
      primaryKey: true
    },
    roomId: {
      type: DataTypes.UUID,
      allowNull: false,
      primaryKey: true
    },
    role: {
      type: DataTypes.ENUM('host', 'co-host', 'participant'),
      defaultValue: 'participant'
    },
    isMuted: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    hasRaisedHand: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    isBlocked: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    joinedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    }
  }, {
    tableName: 'room_participants',
    timestamps: false
  });

  return RoomParticipant;
};

