const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

// Initialize Sequelize with SQLite
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '../database.sqlite'),
  logging: false
});

// Import models
const User = require('./User')(sequelize, DataTypes);
const Room = require('./Room')(sequelize, DataTypes);
const RoomParticipant = require('./RoomParticipant')(sequelize, DataTypes);
const BlockList = require('./BlockList')(sequelize, DataTypes);
const ActivityLog = require('./ActivityLog')(sequelize, DataTypes);
const ChatMessage = require('./ChatMessage')(sequelize, DataTypes);
const File = require('./File')(sequelize, DataTypes);

// Define associations
User.hasMany(Room, { foreignKey: 'createdBy', as: 'createdRooms' });
Room.belongsTo(User, { foreignKey: 'createdBy', as: 'creator' });

User.belongsToMany(Room, { through: RoomParticipant, foreignKey: 'userId', as: 'joinedRooms' });
Room.belongsToMany(User, { through: RoomParticipant, foreignKey: 'roomId', as: 'participants' });

Room.hasMany(RoomParticipant, { foreignKey: 'roomId' });
User.hasMany(RoomParticipant, { foreignKey: 'userId' });
RoomParticipant.belongsTo(Room, { foreignKey: 'roomId' });
RoomParticipant.belongsTo(User, { foreignKey: 'userId' });

Room.hasMany(BlockList, { foreignKey: 'roomId' });
User.hasMany(BlockList, { foreignKey: 'userId' });
BlockList.belongsTo(Room, { foreignKey: 'roomId' });
BlockList.belongsTo(User, { foreignKey: 'userId' });

Room.hasMany(ActivityLog, { foreignKey: 'roomId' });
User.hasMany(ActivityLog, { foreignKey: 'userId' });
ActivityLog.belongsTo(Room, { foreignKey: 'roomId' });
ActivityLog.belongsTo(User, { foreignKey: 'userId' });

Room.hasMany(ChatMessage, { foreignKey: 'roomId' });
User.hasMany(ChatMessage, { foreignKey: 'userId' });
ChatMessage.belongsTo(Room, { foreignKey: 'roomId' });
ChatMessage.belongsTo(User, { foreignKey: 'userId' });

Room.hasMany(File, { foreignKey: 'roomId' });
User.hasMany(File, { foreignKey: 'uploadedBy' });
File.belongsTo(Room, { foreignKey: 'roomId' });
File.belongsTo(User, { foreignKey: 'uploadedBy', as: 'uploader' });

module.exports = {
  sequelize,
  User,
  Room,
  RoomParticipant,
  BlockList,
  ActivityLog,
  ChatMessage,
  File
};

