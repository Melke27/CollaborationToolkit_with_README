const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const Room = sequelize.define('Room', {
    id: {
      type: DataTypes.UUID,
      defaultValue: () => uuidv4(),
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    createdBy: {
      type: DataTypes.UUID,
      allowNull: false
    },
    passwordHash: {
      type: DataTypes.STRING,
      allowNull: true
    },
    waitingRoomEnabled: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    locked: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    sessionTimerMinutes: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    customName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    customLogoUrl: {
      type: DataTypes.STRING,
      allowNull: true
    },
    theme: {
      type: DataTypes.STRING,
      defaultValue: 'light'
    },
    chatEnabled: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    whiteboardEnabled: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    fileShareEnabled: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'rooms',
    timestamps: true
  });

  return Room;
};

