const { RoomParticipant, ActivityLog, ChatMessage, User } = require('../models');

const connectedUsers = new Map(); // userId -> { socketId, roomId }
const roomUsers = new Map(); // roomId -> Set of userIds

module.exports = (io, socket) => {
  console.log('Socket connected:', socket.id);

  // Join room
  socket.on('join-room', async (data) => {
    try {
      const { roomId, userId } = data;
      
      // Verify user is participant
      const participant = await RoomParticipant.findOne({
        where: { userId, roomId }
      });

      if (!participant) {
        socket.emit('error', { message: 'Access denied' });
        return;
      }

      // Join socket room
      socket.join(roomId);
      
      // Track user connection
      connectedUsers.set(userId, { socketId: socket.id, roomId });
      
      if (!roomUsers.has(roomId)) {
        roomUsers.set(roomId, new Set());
      }
      roomUsers.get(roomId).add(userId);

      // Get user info
      const user = await User.findByPk(userId);
      
      // Notify others in room
      socket.to(roomId).emit('user-joined', {
        userId,
        username: user.username,
        role: participant.role
      });

      // Log activity
      await ActivityLog.create({
        roomId,
        userId,
        action: 'joined_session'
      });

      console.log(`User ${userId} joined room ${roomId}`);
    } catch (error) {
      console.error('Join room error:', error);
      socket.emit('error', { message: 'Failed to join room' });
    }
  });

  // Leave room
  socket.on('leave-room', async (data) => {
    try {
      const { roomId, userId } = data;
      
      socket.leave(roomId);
      connectedUsers.delete(userId);
      
      if (roomUsers.has(roomId)) {
        roomUsers.get(roomId).delete(userId);
        if (roomUsers.get(roomId).size === 0) {
          roomUsers.delete(roomId);
        }
      }

      socket.to(roomId).emit('user-left', { userId });

      // Log activity
      await ActivityLog.create({
        roomId,
        userId,
        action: 'left_session'
      });

      console.log(`User ${userId} left room ${roomId}`);
    } catch (error) {
      console.error('Leave room error:', error);
    }
  });

  // Chat message
  socket.on('chat-message', async (data) => {
    try {
      const { roomId, userId, message } = data;
      
      // Verify user is participant
      const participant = await RoomParticipant.findOne({
        where: { userId, roomId }
      });

      if (!participant) {
        socket.emit('error', { message: 'Access denied' });
        return;
      }

      // Save message to database
      const chatMessage = await ChatMessage.create({
        roomId,
        userId,
        message
      });

      // Get user info
      const user = await User.findByPk(userId);

      // Broadcast message to room
      io.to(roomId).emit('chat-message', {
        id: chatMessage.id,
        message: chatMessage.message,
        userId,
        username: user.username,
        timestamp: chatMessage.createdAt
      });
    } catch (error) {
      console.error('Chat message error:', error);
      socket.emit('error', { message: 'Failed to send message' });
    }
  });

  // WebRTC signaling
  socket.on('webrtc-offer', (data) => {
    const { roomId, targetUserId, offer } = data;
    const targetUser = connectedUsers.get(targetUserId);
    
    if (targetUser && targetUser.roomId === roomId) {
      io.to(targetUser.socketId).emit('webrtc-offer', {
        fromUserId: data.fromUserId,
        offer
      });
    }
  });

  socket.on('webrtc-answer', (data) => {
    const { roomId, targetUserId, answer } = data;
    const targetUser = connectedUsers.get(targetUserId);
    
    if (targetUser && targetUser.roomId === roomId) {
      io.to(targetUser.socketId).emit('webrtc-answer', {
        fromUserId: data.fromUserId,
        answer
      });
    }
  });

  socket.on('webrtc-ice-candidate', (data) => {
    const { roomId, targetUserId, candidate } = data;
    const targetUser = connectedUsers.get(targetUserId);
    
    if (targetUser && targetUser.roomId === roomId) {
      io.to(targetUser.socketId).emit('webrtc-ice-candidate', {
        fromUserId: data.fromUserId,
        candidate
      });
    }
  });

  // Media controls
  socket.on('toggle-video', async (data) => {
    const { roomId, userId, enabled } = data;
    
    socket.to(roomId).emit('user-video-toggle', { userId, enabled });
    
    await ActivityLog.create({
      roomId,
      userId,
      action: enabled ? 'enabled_video' : 'disabled_video'
    });
  });

  socket.on('toggle-audio', async (data) => {
    const { roomId, userId, enabled } = data;
    
    socket.to(roomId).emit('user-audio-toggle', { userId, enabled });
    
    await ActivityLog.create({
      roomId,
      userId,
      action: enabled ? 'enabled_audio' : 'disabled_audio'
    });
  });

  socket.on('toggle-screen-share', async (data) => {
    const { roomId, userId, enabled } = data;
    
    socket.to(roomId).emit('user-screen-share-toggle', { userId, enabled });
    
    await ActivityLog.create({
      roomId,
      userId,
      action: enabled ? 'started_screen_share' : 'stopped_screen_share'
    });
  });

  // Whiteboard events
  socket.on('whiteboard-draw', (data) => {
    const { roomId } = data;
    socket.to(roomId).emit('whiteboard-draw', data);
  });

  socket.on('whiteboard-clear', (data) => {
    const { roomId } = data;
    socket.to(roomId).emit('whiteboard-clear', data);
  });

  // Handle disconnect
  socket.on('disconnect', async () => {
    try {
      // Find user by socket ID
      let disconnectedUserId = null;
      let disconnectedRoomId = null;
      
      for (const [userId, userInfo] of connectedUsers.entries()) {
        if (userInfo.socketId === socket.id) {
          disconnectedUserId = userId;
          disconnectedRoomId = userInfo.roomId;
          break;
        }
      }

      if (disconnectedUserId && disconnectedRoomId) {
        connectedUsers.delete(disconnectedUserId);
        
        if (roomUsers.has(disconnectedRoomId)) {
          roomUsers.get(disconnectedRoomId).delete(disconnectedUserId);
          if (roomUsers.get(disconnectedRoomId).size === 0) {
            roomUsers.delete(disconnectedRoomId);
          }
        }

        socket.to(disconnectedRoomId).emit('user-left', { userId: disconnectedUserId });

        // Log activity
        await ActivityLog.create({
          roomId: disconnectedRoomId,
          userId: disconnectedUserId,
          action: 'disconnected'
        });

        console.log(`User ${disconnectedUserId} disconnected from room ${disconnectedRoomId}`);
      }
    } catch (error) {
      console.error('Disconnect error:', error);
    }
  });
};

