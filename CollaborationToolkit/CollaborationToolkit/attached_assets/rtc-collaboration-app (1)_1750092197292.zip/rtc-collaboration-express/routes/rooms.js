const express = require('express');
const bcrypt = require('bcryptjs');
const { Room, RoomParticipant, User, ActivityLog } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Create room
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { name, password, waitingRoomEnabled, sessionTimerMinutes, customName, theme } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Room name is required' });
    }

    const roomData = {
      name,
      createdBy: req.user.id,
      waitingRoomEnabled: waitingRoomEnabled || false,
      sessionTimerMinutes,
      customName,
      theme: theme || 'light'
    };

    if (password) {
      roomData.passwordHash = await bcrypt.hash(password, 10);
    }

    const room = await Room.create(roomData);

    // Add creator as host
    await RoomParticipant.create({
      userId: req.user.id,
      roomId: room.id,
      role: 'host'
    });

    // Log activity
    await ActivityLog.create({
      roomId: room.id,
      userId: req.user.id,
      action: 'created_room'
    });

    res.status(201).json({
      message: 'Room created successfully',
      room: {
        id: room.id,
        name: room.name,
        createdBy: room.createdBy,
        waitingRoomEnabled: room.waitingRoomEnabled,
        locked: room.locked,
        sessionTimerMinutes: room.sessionTimerMinutes,
        customName: room.customName,
        theme: room.theme,
        createdAt: room.createdAt
      }
    });
  } catch (error) {
    console.error('Create room error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Get user's rooms
router.get('/', authenticateToken, async (req, res) => {
  try {
    const rooms = await Room.findAll({
      include: [{
        model: RoomParticipant,
        where: { userId: req.user.id },
        attributes: ['role', 'joinedAt']
      }],
      order: [['createdAt', 'DESC']]
    });

    const roomsData = rooms.map(room => ({
      id: room.id,
      name: room.name,
      createdBy: room.createdBy,
      waitingRoomEnabled: room.waitingRoomEnabled,
      locked: room.locked,
      sessionTimerMinutes: room.sessionTimerMinutes,
      customName: room.customName,
      theme: room.theme,
      createdAt: room.createdAt,
      role: room.RoomParticipants[0]?.role
    }));

    res.json({ rooms: roomsData });
  } catch (error) {
    console.error('Get rooms error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Get specific room
router.get('/:roomId', authenticateToken, async (req, res) => {
  try {
    const { roomId } = req.params;

    const room = await Room.findByPk(roomId);
    if (!room) {
      return res.status(404).json({ message: 'Room not found' });
    }

    const participant = await RoomParticipant.findOne({
      where: { userId: req.user.id, roomId }
    });

    if (!participant) {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json({
      room: {
        id: room.id,
        name: room.name,
        createdBy: room.createdBy,
        waitingRoomEnabled: room.waitingRoomEnabled,
        locked: room.locked,
        sessionTimerMinutes: room.sessionTimerMinutes,
        customName: room.customName,
        theme: room.theme,
        chatEnabled: room.chatEnabled,
        whiteboardEnabled: room.whiteboardEnabled,
        fileShareEnabled: room.fileShareEnabled,
        createdAt: room.createdAt
      },
      participant: {
        role: participant.role,
        isMuted: participant.isMuted,
        hasRaisedHand: participant.hasRaisedHand,
        joinedAt: participant.joinedAt
      }
    });
  } catch (error) {
    console.error('Get room error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Join room
router.post('/:roomId/join', authenticateToken, async (req, res) => {
  try {
    const { roomId } = req.params;
    const { password } = req.body;

    const room = await Room.findByPk(roomId);
    if (!room) {
      return res.status(404).json({ message: 'Room not found' });
    }

    if (room.locked) {
      return res.status(403).json({ message: 'Room is locked' });
    }

    // Check password if required
    if (room.passwordHash && (!password || !await bcrypt.compare(password, room.passwordHash))) {
      return res.status(401).json({ message: 'Invalid room password' });
    }

    // Check if already a participant
    const existingParticipant = await RoomParticipant.findOne({
      where: { userId: req.user.id, roomId }
    });

    if (existingParticipant) {
      return res.status(400).json({ message: 'Already a participant' });
    }

    // Add as participant
    const participant = await RoomParticipant.create({
      userId: req.user.id,
      roomId,
      role: 'participant'
    });

    // Log activity
    await ActivityLog.create({
      roomId,
      userId: req.user.id,
      action: 'joined_room'
    });

    res.json({
      message: 'Joined room successfully',
      participant: {
        role: participant.role,
        isMuted: participant.isMuted,
        hasRaisedHand: participant.hasRaisedHand,
        joinedAt: participant.joinedAt
      }
    });
  } catch (error) {
    console.error('Join room error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Get room participants (host only)
router.get('/:roomId/participants', authenticateToken, async (req, res) => {
  try {
    const { roomId } = req.params;

    // Check if user is host
    const hostParticipant = await RoomParticipant.findOne({
      where: { userId: req.user.id, roomId, role: 'host' }
    });

    if (!hostParticipant) {
      return res.status(403).json({ message: 'Host access required' });
    }

    const participants = await RoomParticipant.findAll({
      where: { roomId },
      include: [{
        model: User,
        attributes: ['id', 'username']
      }]
    });

    const participantsData = participants.map(p => ({
      userId: p.userId,
      username: p.User.username,
      role: p.role,
      isMuted: p.isMuted,
      hasRaisedHand: p.hasRaisedHand,
      joinedAt: p.joinedAt
    }));

    res.json({ participants: participantsData });
  } catch (error) {
    console.error('Get participants error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;

