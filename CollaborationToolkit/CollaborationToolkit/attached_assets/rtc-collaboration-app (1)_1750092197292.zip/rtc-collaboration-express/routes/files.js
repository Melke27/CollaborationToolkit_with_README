const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { File, Room, RoomParticipant, User } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}-${file.originalname}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow common file types
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt|zip|mp4|mp3/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('File type not allowed'));
    }
  }
});

// Upload file
router.post('/upload', authenticateToken, upload.single('file'), async (req, res) => {
  try {
    const { roomId } = req.body;

    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    if (!roomId) {
      return res.status(400).json({ message: 'Room ID is required' });
    }

    // Check if user is participant in the room
    const participant = await RoomParticipant.findOne({
      where: { userId: req.user.id, roomId }
    });

    if (!participant) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Check if room allows file sharing
    const room = await Room.findByPk(roomId);
    if (!room.fileShareEnabled) {
      return res.status(403).json({ message: 'File sharing is disabled in this room' });
    }

    // Save file record to database
    const fileRecord = await File.create({
      filename: req.file.filename,
      originalName: req.file.originalname,
      mimetype: req.file.mimetype,
      filesize: req.file.size,
      uploadedBy: req.user.id,
      roomId,
      filePath: req.file.path
    });

    res.status(201).json({
      message: 'File uploaded successfully',
      file: {
        id: fileRecord.id,
        filename: fileRecord.originalName,
        filesize: fileRecord.filesize,
        mimetype: fileRecord.mimetype,
        uploadedAt: fileRecord.createdAt
      }
    });
  } catch (error) {
    console.error('File upload error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Get files for a room
router.get('/room/:roomId', authenticateToken, async (req, res) => {
  try {
    const { roomId } = req.params;

    // Check if user is participant in the room
    const participant = await RoomParticipant.findOne({
      where: { userId: req.user.id, roomId }
    });

    if (!participant) {
      return res.status(403).json({ message: 'Access denied' });
    }

    const files = await File.findAll({
      where: { roomId },
      include: [{
        model: User,
        as: 'uploader',
        attributes: ['username']
      }],
      order: [['createdAt', 'DESC']]
    });

    const filesData = files.map(file => ({
      id: file.id,
      filename: file.originalName,
      filesize: file.filesize,
      mimetype: file.mimetype,
      uploadedBy: file.uploader.username,
      uploadedAt: file.createdAt
    }));

    res.json({ files: filesData });
  } catch (error) {
    console.error('Get files error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Download file
router.get('/:fileId/download', authenticateToken, async (req, res) => {
  try {
    const { fileId } = req.params;

    const file = await File.findByPk(fileId);
    if (!file) {
      return res.status(404).json({ message: 'File not found' });
    }

    // Check if user is participant in the room
    const participant = await RoomParticipant.findOne({
      where: { userId: req.user.id, roomId: file.roomId }
    });

    if (!participant) {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.download(file.filePath, file.originalName);
  } catch (error) {
    console.error('File download error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;

