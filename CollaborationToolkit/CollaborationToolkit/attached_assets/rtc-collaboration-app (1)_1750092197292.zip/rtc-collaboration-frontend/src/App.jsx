import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './hooks/useAuth'
import { WebRTCProvider } from './hooks/useWebRTC'
import Login from './components/Login'
import Register from './components/Register'
import Dashboard from './components/Dashboard'
import Room from './components/Room'

function App() {
  return (
    <AuthProvider>
      <WebRTCProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/room/:roomId" element={<Room />} />
              <Route path="/" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
        </Router>
      </WebRTCProvider>
    </AuthProvider>
  )
}

export default App

