import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../hooks/useAuth'
import { useWebRTC } from '../hooks/useWebRTC'
import VideoPlayer from './VideoPlayer'
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Monitor, 
  MonitorOff,
  Users, 
  MessageSquare, 
  FileText,
  Settings,
  ArrowLeft,
  Phone
} from 'lucide-react'
import axios from 'axios'

const API_BASE_URL = 'http://localhost:5000/api'

export default function Room() {
  const { roomId } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  
  const {
    localStream,
    peers,
    isVideoEnabled,
    isAudioEnabled,
    isScreenSharing,
    localVideoRef,
    joinRoom,
    toggleVideo,
    toggleAudio,
    startScreenShare,
    stopScreenShare,
    leaveRoom
  } = useWebRTC()
  
  const [room, setRoom] = useState(null)
  const [participant, setParticipant] = useState(null)
  const [participants, setParticipants] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchRoomData()
  }, [roomId])

  useEffect(() => {
    if (room && user) {
      // Join WebRTC room
      joinRoom(roomId, user.id)
    }
  }, [room, user, roomId, joinRoom])

  const fetchRoomData = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/rooms/${roomId}`)
      setRoom(response.data.room)
      setParticipant(response.data.participant)
    } catch (error) {
      setError('Failed to load room data')
      console.error('Failed to fetch room:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLeaveRoom = () => {
    leaveRoom()
    navigate('/dashboard')
  }

  const handleScreenShare = () => {
    if (isScreenSharing) {
      stopScreenShare()
    } else {
      startScreenShare()
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <p className="text-red-600 mb-4">{error}</p>
            <Button onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const peerList = Object.values(peers)

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/dashboard')}
                className="mr-4 text-gray-300 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <h1 className="text-xl font-semibold">{room?.name}</h1>
              {participant?.role === 'host' && (
                <Badge variant="secondary" className="ml-3">Host</Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-gray-300">
                <Users className="h-3 w-3 mr-1" />
                {peerList.length + 1}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-4rem)]">
        {/* Video Area */}
        <div className="flex-1 flex flex-col p-4">
          {/* Video Grid */}
          <div className="flex-1 grid gap-4" style={{
            gridTemplateColumns: peerList.length === 0 ? '1fr' : 
                                 peerList.length === 1 ? 'repeat(2, 1fr)' :
                                 peerList.length <= 4 ? 'repeat(2, 1fr)' :
                                 'repeat(3, 1fr)'
          }}>
            {/* Local Video */}
            <div className="relative bg-gray-800 rounded-lg overflow-hidden min-h-[200px]">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
                {user?.username} (You)
              </div>
              {!isVideoEnabled && (
                <div className="absolute inset-0 bg-gray-700 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-xl font-semibold">
                        {user?.username?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm">Camera Off</p>
                  </div>
                </div>
              )}
            </div>

            {/* Remote Videos */}
            {peerList.map((peerData) => (
              <VideoPlayer
                key={peerData.userId}
                stream={peerData.stream}
                userId={peerData.userId}
                username={`User ${peerData.userId.slice(0, 8)}`}
              />
            ))}
          </div>

          {/* Controls */}
          <div className="bg-gray-800 p-4 rounded-lg mt-4">
            <div className="flex justify-center space-x-4">
              <Button
                variant={isAudioEnabled ? "default" : "destructive"}
                size="lg"
                onClick={toggleAudio}
                className="rounded-full w-12 h-12"
              >
                {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
              </Button>
              
              <Button
                variant={isVideoEnabled ? "default" : "destructive"}
                size="lg"
                onClick={toggleVideo}
                className="rounded-full w-12 h-12"
              >
                {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
              </Button>
              
              <Button
                variant={isScreenSharing ? "secondary" : "outline"}
                size="lg"
                onClick={handleScreenShare}
                className="rounded-full w-12 h-12"
              >
                {isScreenSharing ? <MonitorOff className="h-5 w-5" /> : <Monitor className="h-5 w-5" />}
              </Button>
              
              <Button
                variant="destructive"
                size="lg"
                onClick={handleLeaveRoom}
                className="rounded-full w-12 h-12"
              >
                <Phone className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
          {/* Participants */}
          <div className="p-4 border-b border-gray-700">
            <h3 className="font-semibold mb-3 flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Participants ({peerList.length + 1})
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-gray-700 rounded">
                <span className="text-sm">{user?.username} (You)</span>
                {participant?.role === 'host' && (
                  <Badge variant="secondary" size="sm">Host</Badge>
                )}
              </div>
              {peerList.map((peerData, index) => (
                <div key={peerData.userId} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                  <span className="text-sm">User {peerData.userId.slice(0, 8)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Chat Placeholder */}
          <div className="flex-1 p-4">
            <h3 className="font-semibold mb-3 flex items-center">
              <MessageSquare className="h-4 w-4 mr-2" />
              Chat
            </h3>
            <div className="bg-gray-700 rounded p-4 text-center text-gray-400">
              <MessageSquare className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">Chat feature coming in next phase</p>
            </div>
          </div>

          {/* Tools */}
          <div className="p-4 border-t border-gray-700">
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" className="text-gray-300">
                <FileText className="h-4 w-4 mr-2" />
                Files
              </Button>
              <Button variant="outline" size="sm" className="text-gray-300">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

