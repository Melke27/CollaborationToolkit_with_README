import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../hooks/useAuth'
import { Video, Users, Plus, LogOut, Settings } from 'lucide-react'
import axios from 'axios'

const API_BASE_URL = 'http://localhost:5000/api'

export default function Dashboard() {
  const [rooms, setRooms] = useState([])
  const [newRoomName, setNewRoomName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    fetchRooms()
  }, [])

  const fetchRooms = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/rooms`)
      setRooms(response.data.rooms)
    } catch (error) {
      console.error('Failed to fetch rooms:', error)
      setError('Failed to load rooms')
    }
  }

  const createRoom = async (e) => {
    e.preventDefault()
    if (!newRoomName.trim()) return

    setLoading(true)
    setError('')

    try {
      const response = await axios.post(`${API_BASE_URL}/rooms`, {
        name: newRoomName
      })
      
      setRooms([...rooms, response.data.room])
      setNewRoomName('')
      navigate(`/room/${response.data.room.id}`)
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to create room')
    } finally {
      setLoading(false)
    }
  }

  const joinRoom = (roomId) => {
    navigate(`/room/${roomId}`)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Video className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-xl font-semibold text-gray-900">RTC Collaboration</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">Welcome, {user?.username}</span>
              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Create Room Section */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="h-5 w-5 mr-2" />
                Create New Room
              </CardTitle>
              <CardDescription>
                Start a new video conference or collaboration session
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={createRoom} className="flex space-x-4">
                <div className="flex-1">
                  <Input
                    type="text"
                    value={newRoomName}
                    onChange={(e) => setNewRoomName(e.target.value)}
                    placeholder="Enter room name"
                    required
                  />
                </div>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Creating...' : 'Create Room'}
                </Button>
              </form>
              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Rooms List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Your Rooms
              </CardTitle>
              <CardDescription>
                Rooms you've created or joined
              </CardDescription>
            </CardHeader>
            <CardContent>
              {rooms.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No rooms yet. Create your first room to get started!</p>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {rooms.map((room) => (
                    <Card key={room.id} className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-lg">{room.name}</h3>
                          {room.created_by === user?.id && (
                            <Badge variant="secondary">Owner</Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-4">
                          Created {new Date(room.created_at).toLocaleDateString()}
                        </p>
                        <Button 
                          onClick={() => joinRoom(room.id)}
                          className="w-full"
                        >
                          Join Room
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

