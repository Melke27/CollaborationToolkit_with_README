import { useEffect, useRef } from 'react'

export default function VideoPlayer({ stream, muted = false, userId, username }) {
  const videoRef = useRef()

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream
    }
  }, [stream])

  return (
    <div className="relative bg-gray-800 rounded-lg overflow-hidden">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted={muted}
        className="w-full h-full object-cover"
      />
      {username && (
        <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
          {username} {muted && '(You)'}
        </div>
      )}
      {!stream && (
        <div className="absolute inset-0 flex items-center justify-center text-gray-400">
          <div className="text-center">
            <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-xl font-semibold">
                {username ? username.charAt(0).toUpperCase() : '?'}
              </span>
            </div>
            <p className="text-sm">{username || 'Unknown User'}</p>
          </div>
        </div>
      )}
    </div>
  )
}

