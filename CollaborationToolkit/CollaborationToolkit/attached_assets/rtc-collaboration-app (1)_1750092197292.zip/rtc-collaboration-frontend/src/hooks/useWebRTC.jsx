import { createContext, useContext, useState, useEffect, useRef } from 'react'
import io from 'socket.io-client'
import Peer from 'simple-peer'

const WebRTCContext = createContext()

export function WebRTCProvider({ children }) {
  const [socket, setSocket] = useState(null)
  const [localStream, setLocalStream] = useState(null)
  const [peers, setPeers] = useState({})
  const [isVideoEnabled, setIsVideoEnabled] = useState(true)
  const [isAudioEnabled, setIsAudioEnabled] = useState(true)
  const [isScreenSharing, setIsScreenSharing] = useState(false)
  const [roomId, setRoomId] = useState(null)
  const [userId, setUserId] = useState(null)
  
  const peersRef = useRef({})
  const localVideoRef = useRef()

  useEffect(() => {
    // Initialize socket connection
    const newSocket = io('http://localhost:5000')
    setSocket(newSocket)

    return () => {
      if (newSocket) {
        newSocket.disconnect()
      }
    }
  }, [])

  const initializeMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      })
      
      setLocalStream(stream)
      
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream
      }
      
      return stream
    } catch (error) {
      console.error('Error accessing media devices:', error)
      throw error
    }
  }

  const joinRoom = async (roomId, userId) => {
    try {
      setRoomId(roomId)
      setUserId(userId)
      
      const stream = await initializeMedia()
      
      if (socket) {
        socket.emit('join-room', { roomId, userId })
        
        // Listen for other users joining
        socket.on('user-joined', ({ userId: newUserId, username }) => {
          console.log('User joined:', newUserId)
          createPeer(newUserId, true, stream)
        })
        
        // Listen for WebRTC offers
        socket.on('webrtc-offer', ({ fromUserId, offer }) => {
          console.log('Received offer from:', fromUserId)
          createPeer(fromUserId, false, stream, offer)
        })
        
        // Listen for WebRTC answers
        socket.on('webrtc-answer', ({ fromUserId, answer }) => {
          console.log('Received answer from:', fromUserId)
          const peer = peersRef.current[fromUserId]
          if (peer) {
            peer.signal(answer)
          }
        })
        
        // Listen for ICE candidates
        socket.on('webrtc-ice-candidate', ({ fromUserId, candidate }) => {
          console.log('Received ICE candidate from:', fromUserId)
          const peer = peersRef.current[fromUserId]
          if (peer) {
            peer.signal(candidate)
          }
        })
        
        // Listen for users leaving
        socket.on('user-left', ({ userId: leftUserId }) => {
          console.log('User left:', leftUserId)
          if (peersRef.current[leftUserId]) {
            peersRef.current[leftUserId].destroy()
            delete peersRef.current[leftUserId]
            setPeers(prev => {
              const newPeers = { ...prev }
              delete newPeers[leftUserId]
              return newPeers
            })
          }
        })
      }
    } catch (error) {
      console.error('Error joining room:', error)
    }
  }

  const createPeer = (targetUserId, initiator, stream, offer = null) => {
    const peer = new Peer({
      initiator,
      trickle: false,
      stream
    })

    peer.on('signal', (signal) => {
      if (socket) {
        if (signal.type === 'offer') {
          socket.emit('webrtc-offer', {
            roomId,
            targetUserId,
            fromUserId: userId,
            offer: signal
          })
        } else if (signal.type === 'answer') {
          socket.emit('webrtc-answer', {
            roomId,
            targetUserId,
            fromUserId: userId,
            answer: signal
          })
        } else {
          socket.emit('webrtc-ice-candidate', {
            roomId,
            targetUserId,
            fromUserId: userId,
            candidate: signal
          })
        }
      }
    })

    peer.on('stream', (remoteStream) => {
      console.log('Received remote stream from:', targetUserId)
      setPeers(prev => ({
        ...prev,
        [targetUserId]: {
          peer,
          stream: remoteStream,
          userId: targetUserId
        }
      }))
    })

    peer.on('error', (error) => {
      console.error('Peer error:', error)
    })

    peer.on('close', () => {
      console.log('Peer connection closed:', targetUserId)
    })

    if (offer) {
      peer.signal(offer)
    }

    peersRef.current[targetUserId] = peer
  }

  const toggleVideo = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.enabled = !isVideoEnabled
        setIsVideoEnabled(!isVideoEnabled)
        
        if (socket) {
          socket.emit('toggle-video', {
            roomId,
            userId,
            enabled: !isVideoEnabled
          })
        }
      }
    }
  }

  const toggleAudio = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = !isAudioEnabled
        setIsAudioEnabled(!isAudioEnabled)
        
        if (socket) {
          socket.emit('toggle-audio', {
            roomId,
            userId,
            enabled: !isAudioEnabled
          })
        }
      }
    }
  }

  const startScreenShare = async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      })
      
      // Replace video track in all peer connections
      Object.values(peersRef.current).forEach(peer => {
        const videoTrack = screenStream.getVideoTracks()[0]
        const sender = peer._pc.getSenders().find(s => 
          s.track && s.track.kind === 'video'
        )
        if (sender) {
          sender.replaceTrack(videoTrack)
        }
      })
      
      // Update local video
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = screenStream
      }
      
      setIsScreenSharing(true)
      
      // Listen for screen share end
      screenStream.getVideoTracks()[0].onended = () => {
        stopScreenShare()
      }
      
      if (socket) {
        socket.emit('toggle-screen-share', {
          roomId,
          userId,
          enabled: true
        })
      }
    } catch (error) {
      console.error('Error starting screen share:', error)
    }
  }

  const stopScreenShare = async () => {
    try {
      // Get camera stream back
      const cameraStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      })
      
      // Replace screen track with camera track in all peer connections
      Object.values(peersRef.current).forEach(peer => {
        const videoTrack = cameraStream.getVideoTracks()[0]
        const sender = peer._pc.getSenders().find(s => 
          s.track && s.track.kind === 'video'
        )
        if (sender) {
          sender.replaceTrack(videoTrack)
        }
      })
      
      // Update local video
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = cameraStream
      }
      
      setLocalStream(cameraStream)
      setIsScreenSharing(false)
      
      if (socket) {
        socket.emit('toggle-screen-share', {
          roomId,
          userId,
          enabled: false
        })
      }
    } catch (error) {
      console.error('Error stopping screen share:', error)
    }
  }

  const leaveRoom = () => {
    // Stop local stream
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop())
      setLocalStream(null)
    }
    
    // Close all peer connections
    Object.values(peersRef.current).forEach(peer => {
      peer.destroy()
    })
    peersRef.current = {}
    setPeers({})
    
    // Emit leave room event
    if (socket) {
      socket.emit('leave-room', { roomId, userId })
    }
    
    setRoomId(null)
    setUserId(null)
  }

  const value = {
    socket,
    localStream,
    peers,
    isVideoEnabled,
    isAudioEnabled,
    isScreenSharing,
    localVideoRef,
    joinRoom,
    toggleVideo,
    toggleAudio,
    startScreenShare,
    stopScreenShare,
    leaveRoom
  }

  return (
    <WebRTCContext.Provider value={value}>
      {children}
    </WebRTCContext.Provider>
  )
}

export function useWebRTC() {
  const context = useContext(WebRTCContext)
  if (!context) {
    throw new Error('useWebRTC must be used within a WebRTCProvider')
  }
  return context
}

